
package abastractfactotory1;


public class SamsungExpert implements NotbookDesenvolverdor{

   
    @Override
    public void exibirinfoNotbookDesenvolvedor() {
   
        System.out.println("Notebook Desenvolvedor:");
        System.out.println("8GB Memoria, Processador I7 placa de video 2GB");
        System.out.println("------------------------------");
    }
    
}
// apresentação do produto