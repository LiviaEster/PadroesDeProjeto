
package abastractfactotory1;


public interface FabricaNotebook {
 
     NotbookComum criarNotbookComum();
     NotbookGamer crairNotbookGamer();
     NotbookDesenvolverdor criaNotbookDesenvolvedor();
     
} // recebe a informação
 
