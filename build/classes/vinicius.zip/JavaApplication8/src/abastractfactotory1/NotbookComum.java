
package abastractfactotory1;

public interface NotbookComum {
    
    void exibirInfoNotbookComum();
}
