
package abastractfactotory1;


public class Samsung implements NotbookComum { 

    @Override
    public void exibirInfoNotbookComum() {
        
        System.out.println("Notebook comum:");
        System.out.println("2GB Memoria, Processador I3");
        System.out.println("------------------------------");
        
    }
    //informa o escolhido
}
