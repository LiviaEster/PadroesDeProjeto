
package abastractfactotory1;


public interface NotbookGamer {
    
    void exibirNotbookGamer();
}
