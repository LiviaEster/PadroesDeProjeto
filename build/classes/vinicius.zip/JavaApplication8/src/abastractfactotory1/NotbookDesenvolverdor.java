
package abastractfactotory1;


public interface NotbookDesenvolverdor {
    
    void exibirinfoNotbookDesenvolvedor();
}
