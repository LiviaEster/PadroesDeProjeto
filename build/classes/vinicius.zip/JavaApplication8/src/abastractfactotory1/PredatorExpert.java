
package abastractfactotory1;

public class PredatorExpert implements NotbookGamer{

    @Override
    public void exibirNotbookGamer() {
    
        System.out.println("Notebook Gamaer:");
        System.out.println("16GB Memoria, Processador I7 4GB de placa de video");
        System.out.println("------------------------------");
    
    }
    
} // informa o escolhido
