package factoryMethod;

public abstract class Celular {

    public String marca;
    public String modelo;
 
}

