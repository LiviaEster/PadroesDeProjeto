package factoryMethod;

public class CelularApple extends Celular {
    public CelularApple(String modelo) {
    this.modelo = modelo;
    System.out.println("Celular Apple. Modelo: " + this.modelo);
  
    }
 
}