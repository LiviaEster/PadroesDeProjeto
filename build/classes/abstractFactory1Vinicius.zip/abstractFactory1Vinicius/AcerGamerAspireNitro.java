package abstractFactory1Vinicius;
   
public class AcerGamerAspireNitro implements NotbookGamer { 

   @Override
    public void exibirNotbookGamer() {
    
        System.out.println("Notebook Gamer Acer:");
        System.out.println("16GB Memoria, Processador I7 4GB de placa de video");
        System.out.println("------------------------------");
    
    }
}
