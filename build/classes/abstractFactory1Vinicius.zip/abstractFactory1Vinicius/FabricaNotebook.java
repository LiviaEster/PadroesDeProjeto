package abstractFactory1Vinicius;

public interface FabricaNotebook {
 
     NotbookComum criarNotbookComum();
     NotbookGamer crairNotbookGamer();
     NotbookDesenvolverdor criaNotbookDesenvolvedor();
     
} // recebe a informação
 
