
package abstractFactory1Vinicius;


public interface NotbookGamer {
    
    void exibirNotbookGamer();
}
