package abstractFactory1Vinicius;

public class AcerAspire5 implements NotbookDesenvolverdor{ 

    @Override
    public void exibirinfoNotbookDesenvolvedor() {
   
        System.out.println("Notebook Desenvolvedor Acer:");
        System.out.println("8GB Memoria, Processador I7 placa de video 2GB");
        System.out.println("------------------------------");
    }
    
}

