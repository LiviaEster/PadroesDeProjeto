
package abstractFactory1Vinicius;


public interface NotbookDesenvolverdor {
    
    void exibirinfoNotbookDesenvolvedor();
}
