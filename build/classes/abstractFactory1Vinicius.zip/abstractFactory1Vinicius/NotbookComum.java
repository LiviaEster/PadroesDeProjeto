
package abstractFactory1Vinicius;

public interface NotbookComum {
    
    void exibirInfoNotbookComum();
}
