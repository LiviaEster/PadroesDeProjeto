/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractyFactory2;

/**
 *
 * @author livia
 */
public class iPhone4 implements CelularEmConta{

    @Override
    public void exibirInfoCelularMaisEmConta() {
        System.out.println("Marca:Apple Linha:iPhone4");
    }
    
}
