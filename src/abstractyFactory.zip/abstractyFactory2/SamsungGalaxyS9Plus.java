/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractyFactory2;

/**
 *
 * @author livia
 */
public class SamsungGalaxyS9Plus implements CelularMaisCaro {
    
    @Override
    public void exibirInfoCelularMaisCaro() {
        System.out.println("Marca:Samsung Linha:GalaxyS9Plus");
    }
    
}
